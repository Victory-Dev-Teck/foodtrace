import React from "react";
import {createRoot} from 'react-dom/client';
import {RestDataSource} from '../../service/RestDataSource'
import {Col, Row, Button} from '@themesberg/react-bootstrap';
import '../../css/dashboard.css';
import "../../css/monthPickerStyle.css";
import ButtonGroup from "../ButtonGroup";
import Select from 'react-select';
import "../../css/monthPickerStyle.css";
import DateRangePicker from "@wojtekmaj/react-daterange-picker";
import EquipmentTimeChart from "./EquipmentTimeChart";



const customControlStyles = base => ({
    ...base,
    marginTop:5,
    height: 33,
    minHeight: 33,
});
class DashboardOverview extends React.Component {

    constructor(props) {
        super(props);
        this.dataSource = new RestDataSource(process.env.MIX_APP_URL, (err) => console.log(err));
        this.state = {
            dateRange1: [this.getMonday(), new Date()],
            scheduleOptions: [{value: 0, label: "All"},
                {value: 1, label: "A"},
                {value: 2, label: "B"}],
            scheduleOption: {value: 0, label: "All"},
            recipesOptions:[],
            selectedRecipe:{value:0, label:"All"}
        };

    };

    getMonday() {
        let d = new Date();
        let day = d.getDay(),
            diff = d.getDate() - day + (day == 0 ? -6:1); // adjust when day is sunday

        let monday= new Date(d.setDate(diff));
        let fromDate = monday.getFullYear() + "-" + ("0"+(monday.getMonth() + 1)).substr(-2) + "-" + ("0"+monday.getDate()).substr(-2);
        let dateFrom=new Date(fromDate);
        // let dateFrom=this.convertLocalTimeToUTCString(fromDate,"00:00:00");
        return dateFrom
    }
    getToday(){
        let d=new Date();
        let today=d.getFullYear() + "-" + ("0"+(d.getMonth() + 1)).substr(-2) + "-" + ("0"+d.getDate()).substr(-2);
        let todayFrom=new Date(today);
        return todayFrom;
    }

    setScheduleOption(option){
        this.setState({scheduleOption:option},()=>{
            console.log(this.state.scheduleOption)
        });
    }

    setRecipesOption(option){
        this.setState({selectedRecipe:option},()=>{
            console.log(this.state.selectedRecipe)
        });
    }

    componentDidMount() {
        this.refresh();
        // this.interval = setInterval(() => this.refreshAll(), 50000);
    }

    refresh() {
        this.dataSource.GetRequest("/dashboard/v1/recipes",
            data => {
                this.setState({recipesOptions: data});
            });
    }

    render() {
        return (
            <div className="dashboard-container">

                <Row className="section-container">
                    <Row>
                        <ButtonGroup></ButtonGroup>
                    </Row>
                    <Row className='top-section'>
                        <span className="section-title">Equipment vs Time</span>
                    </Row>
                    <Row className='setting-row-container'>
                        <Col className="filter-section">
                            <span className={"select-title"}>Recipes
                            </span>
                            <span>
                                <Select
                                    className="select-box"
                                    defaultValue={this.state.selectedRecipe}
                                    onChange={(option)=>this.setRecipesOption(option)}
                                    options={this.state.recipesOptions}
                                    styles={{control: customControlStyles}}
                                />
                            </span>
                            <span className={"select-title"}>Schedules
                            </span>
                            <span>
                                <Select
                                    className="short-select-box"
                                    defaultValue={this.state.scheduleOption}
                                    onChange={(option)=>this.setScheduleOption(option)}
                                    options={this.state.scheduleOptions}
                                    styles={{control: customControlStyles}}
                                />
                            </span>
                        </Col>
                        <Col className={"date-picker-section"}>
                            <span className='date-picker-group'>
                            <span>
                                <Button variant="primary" className="mb-2 me-2 date-picker-button"
                                        onClick={() => this.setState({dateRange1:[this.getMonday(), new Date()]})}>
                                    This week so far: Monday to now
                                        </Button>
                            </span>
                            <span>
                                <Button variant="primary" className="mb-2 me-2 date-picker-button"
                                        onClick={() => this.setState({dateRange1:[this.getToday(), new Date()]})}>
                                    Today
                                        </Button>
                            </span>
                            <span>
                                <DateRangePicker
                                    calendarAriaLabel="Toggle calendar"
                                    clearAriaLabel="Clear value"
                                    rangeDivider="~"
                                    dayAriaLabel="Day"
                                    monthAriaLabel="Month"
                                    nativeInputAriaLabel="Date"
                                    clearIcon={null}
                                    onChange={(value) => this.setState({ dateRange1: value })}
                                    value={this.state.dateRange1}
                                    yearAriaLabel="Year"
                                />
                            </span>
                        </span>
                        </Col>
                    </Row>
                </Row>


                <Row>
                    <Col xs={12} sm={12} lg={12} xl={12}>
                        <EquipmentTimeChart dataSource={this.dataSource} dateRange={this.state.dateRange1} recipeCateg={this.state.selectedRecipe} scheduleCateg={this.state.scheduleOption}/>
                    </Col>
                </Row>
            </div>
        );
    }

}

export default DashboardOverview;


const root = createRoot(document.getElementById('equipment-time'));
root.render(<DashboardOverview/>);