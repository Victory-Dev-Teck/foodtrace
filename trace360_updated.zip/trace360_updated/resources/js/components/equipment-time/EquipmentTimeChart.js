import React, {useState, useEffect} from 'react';
import ReactApexChart from 'react-apexcharts';
import {getUtcTimeStamp} from '../../modules/date_parser';

const EquipmentTimeChart = (props) => {

    const [series, setSeries] = useState([
        {
            "name": "",
            "data": [
                {
                    x: "",
                    y: [
                        new Date('2020-01-01').getTime(),
                        new Date('2020-01-02').getTime()
                    ],
                    minutes: 1
                },
            ]
        }
    ]);


    const [options, setOptions] = useState({

        chart: {
            height: 350,
            type: 'rangeBar',
            // background: "#141619",
            // foreColor: '#ffffff',
            toolbar: {
                show: true,
            }
        },
        grid: {
            show: true,
            borderColor: '#ffffff',
            strokeDashArray: 0,
            position: 'back',
            xaxis: {
                lines: {
                    show: false
                }
            },
            yaxis: {
                lines: {
                    show: false
                }
            }
        },
        plotOptions: {
            bar: {
                horizontal: true,
                barHeight: '50%',
                rangeBarGroupRows: true
            }
        },
        legend: {
            show: false,
        },

        xaxis: {
            type: 'datetime',
            min: props.dateRange[0].getTime(),
            max: props.dateRange[1].getTime(),
            axisBorder: {
                show: true,
                color: '#78909C',
                height: 1,
                width: '100%',
                offsetX: 0,
                offsetY: 0
            },
            axisTicks: {
                show: true,
                borderType: 'solid',
                color: '#78909C',
                height: 6,
                offsetX: 0,
                offsetY: 0
            },
        },
        yaxis: {
            axisBorder: {
                show: true,
                color: '#78909C',
                height: '100%',
                width: 1,
                offsetX: 0,
                offsetY: 0
            },
            axisTicks: {
                show: true,
                borderType: 'solid',
                color: '#78909C',
                width: 6,
                offsetX: 0,
                offsetY: 0
            },
        },
        tooltip: {
            y: {
                formatter: function (value, { series, seriesIndex, dataPointIndex, w }) {
                    var data = w.globals.initialSeries[seriesIndex].data[dataPointIndex];
                    return '<div>' +
                        '<div><b>' + value + '</b></div>'+
                        '<div><b>' + secondsToDhms(data.minutes) + '</b></div>'+
                        // '<li><b>Duration</b>: \'' + data.minutes + '\'</li>'
                        '</div>'
                },
            },
            x: {
                show: true,
                format: 'MMM/dd HH:mm:ss',
                // formatter: undefined,
            },

        }
    });


    function secondsToDhms(seconds) {
        seconds = Number(seconds);
        var d = Math.floor(seconds / (3600 * 24));
        var h = Math.floor(seconds % (3600 * 24) / 3600);
        var m = Math.floor(seconds % 3600 / 60);
        var s = Math.floor(seconds % 60);

        var dDisplay = d > 0 ? d + (d == 1 ? " day " : " days ") : "";
        var hDisplay = h > 0 ? h + (h == 1 ? " hour " : " hours ") : "";
        var mDisplay = m > 0 ? m + (m == 1 ? " min " : " mins ") : "";
        var sDisplay = s > 0 ? s + (s == 1 ? " sec" : " secs") : "";
        return dDisplay + hDisplay + mDisplay + sDisplay;
    }

    useEffect(() => {
        setOptions(prevOption => ({
                ...prevOption, xaxis: {
                    type: 'datetime',
                    min: props.dateRange[0].getTime(),
                    max: props.dateRange[1].getTime(),
                }
            }
        ));
        let request_data = {
            from: {
                year: props.dateRange[0].getFullYear(),
                month: props.dateRange[0].getMonth(),
                day: props.dateRange[0].getDate()
            },
            to: {
                year: props.dateRange[1].getFullYear(),
                month: props.dateRange[1].getMonth(),
                day: props.dateRange[1].getDate()
            }
        };

        props.dataSource.PostRequest("/dashboard/v1/equipment-time?schedule=" + props.scheduleCateg.value + "&recipe_id=" + props.recipeCateg.value,
            equip_data => {
            console.log(equip_data);
                let newSeries = [];
                let prevRecipe = "";

                if (equip_data.length>0){
                    equip_data.map(item => {
                        // if (item.Recipes == prevRecipe) {
                        //     let newRecipe = {
                        //         x: item.Text,
                        //         y: [
                        //             getUtcTimeStamp(item.StartTime),
                        //             getUtcTimeStamp(item.EndTime)
                        //         ],
                        //         minutes: item.minutes
                        //     };
                        //     newSeries[newSeries.length - 1].data.push(newRecipe);
                        // } else {
                            let newEquip = {
                                "name": item.Recipes,
                                "data": [
                                    {
                                        x: item.Text,
                                        y: [
                                            getUtcTimeStamp(item.StartTime),
                                            getUtcTimeStamp(item.EndTime)
                                        ],
                                        minutes: item.minutes
                                    },
                                ]
                            };
                            newSeries.push(newEquip);
                        // }
                        prevRecipe=item.Recipes;

                    });
                } else {
                    let newEquip = {
                        "name": "",
                        "data": [
                            {
                                x: "",
                                y: [
                                    new Date('2020-01-01').getTime(),
                                    new Date('2020-01-02').getTime()
                                ],
                                minutes: 1
                            },
                        ]
                    };
                    newSeries.push(newEquip);
                }

                setSeries(newSeries);

            }, request_data);

        // setOptions(prevOptions => ({
        //     ...prevOptions, plotOptions: {
        //         ...prevOptions.plotOptions, radialBar: {
        //             ...prevOptions.plotOptions.radialBar, dataLabels: {
        //                 ...prevOptions.plotOptions.radialBar.dataLabels, value: {
        //                     formatter: (val) => labelFormatter(val),
        //                     show: true,
        //                     color: getTextColor(props.deviceStartState.logs),
        //                     fontSize: props.pWidth/10+'px',
        //                     offsetY: 5,
        //                 }
        //             }
        //         }
        //     }
        // }));

    }, [props.dateRange, props.recipeCateg, props.scheduleCateg]);

    return (
        <div id="chart">
            <ReactApexChart options={options} series={series} type="rangeBar" height="500px"/>
        </div>


    );
};

export default EquipmentTimeChart;