import React from 'react'
import ReactTable from 'react-table-v6'
import 'react-table-v6/react-table.css'


class SortableTable extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        const columns = [{
            Header: 'Ref ID',
            accessor: 'Ref ID', // String-based value accessors!
            // Cell: props => <input type="checkbox" onClick={me.onCheck} />
            // width: 50, // A hardcoded width for the column. This overrides both min and max width options
            // minWidth: 100, // A minimum width for this column. If there is extra room, column will flex to fill available space (up to the max-width, if set)
            maxWidth: undefined, // A maximum width for this column.
            style: {
                color: "#777",
            }, // Set the style of the `td` element of the column
            // Header & HeaderGroup Options
            headerClassName: '', // Set the classname of the `th` element of the column
            headerStyle: {
                color: "#33A2E5"
            },
        },
            {
                Header: 'Machine',
                accessor:
                    'Machine',
                style: {
                    color: "#777",
                }, // Set the style of the `td` element of the column
                // Header & HeaderGroup Options
                headerClassName: '', // Set the classname of the `th` element of the column
                headerStyle: {
                    color: "#33A2E5"
                },
            }
            ,
            {
                Header: 'Recipes',
                accessor:
                    'Recipes',
                style: {
                    color: "#777",
                },
                // Header & HeaderGroup Options
                headerClassName: '', // Set the classname of the `th` element of the column
                headerStyle: {
                    color: "#33A2E5"
                },
            }
            ,
            {
                Header: 'Process',
                accessor:
                    'Process',
                style: {
                    color: "#777",
                },
                // Header & HeaderGroup Options
                headerClassName: '', // Set the classname of the `th` element of the column
                headerStyle: {
                    color: "#33A2E5"
                },
            }
            ,
            {
                Header: 'Log Client Station',
                accessor:
                    'Log Client Station',
                style: {
                    color: "#777",
                },
                // Header & HeaderGroup Options
                headerClassName: '', // Set the classname of the `th` element of the column
                headerStyle: {
                    color: "#33A2E5"
                },
            }
            ,
            {
                Header: 'Start Time',
                accessor:
                    'Start Time',
                style: {
                    color: "#777",
                },
                // Header & HeaderGroup Options
                headerClassName: '', // Set the classname of the `th` element of the column
                headerStyle: {
                    color: "#33A2E5"
                },
            }
            ,
            {
                Header: 'Duration',
                accessor:
                    'Duration',
                style: {
                    color: "#777",
                },
                // Header & HeaderGroup Options
                headerClassName: '', // Set the classname of the `th` element of the column
                headerStyle: {
                    color: "#33A2E5",
                },
            }
        ];

        return <ReactTable
            data={this.props.products}
            columns={columns}
            showPagination={false}
            pageSize={this.props.products.length > 15 ? this.props.products.length : 15}
            style={{
                height: "600px" // This will force the table body to overflow and scroll, since there is not enough room
            }}
        />
    }
}

export default SortableTable;
