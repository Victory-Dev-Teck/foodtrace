import React, {useState, useEffect, useRef } from 'react';
import {Card, CardBody, CardHeader} from "react-simple-card";
import SortableTable from "./SortableTable";
import "../../css/cardStyle.css"
import "./current-production.css"

const TableContainer = (props) => {

    return (
        <Card style={{margin: '20px, 0px, 20px, 0px'}}
              className="card-container" bgColor="#e2e8e8"
        >
            <CardHeader>
                <div className="props-title">
                    {props.title}
                </div>
            </CardHeader>
            <CardBody>
                {/*{props.devices.map((item, index) => {*/}
                        {/*return <Col ref={colRef} key={'top_column_' + item.id + item.name} xs={12} md={4} lg={3} xl={1}*/}
                        {/*>*/}
                            {/*<Gauge deviceStartState={item} max_log={props.maxLog} pWidth={colRef.current==undefined?150:colRef.current.offsetWidth<120?120:colRef.current.offsetWidth}/>*/}
                        {/*</Col>*/}
                       {/**/}
                    {/*}*/}
                {/*)}*/}
                <SortableTable products={props.products}/>
            </CardBody>
        </Card>

    );

};


export default TableContainer;
