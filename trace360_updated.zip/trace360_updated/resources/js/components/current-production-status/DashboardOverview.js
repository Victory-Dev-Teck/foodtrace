import React from "react";
import {createRoot} from 'react-dom/client';
import {RestDataSource} from '../../service/RestDataSource'
import {Col, Row, Button} from '@themesberg/react-bootstrap';
import '../../css/dashboard.css';
import "../../css/monthPickerStyle.css";
import TableContainer from "./TableContainer";
import ButtonGroup from "../ButtonGroup";


class DashboardOverview extends React.Component {

    constructor(props) {
        super(props);
        this.dataSource = new RestDataSource(process.env.MIX_APP_URL, (err) => this.props.history.push('/error/${err}'));
        this.state = {
            machineStatus: [],
            manualStatus: []
        }

    };

    componentDidMount() {
        this.refreshCurrentProducts();
        // this.interval = setInterval(() => this.refreshAll(), 50000);
    }
    refreshCurrentProducts() {
        this.dataSource.GetRequest("/dashboard/v1/current-production-status?machine=1",
            data => {
                this.setState({machineStatus: data});
            });
        this.dataSource.GetRequest("/dashboard/v1/current-production-status?machine=2",
            data => {
                this.setState({manualStatus: data});
            });
    }

    render() {
        return (
            <div className="dashboard-container">

                <Row className="section-container">
                    <Row>
                        <ButtonGroup></ButtonGroup>
                    </Row>
                    <Row className='top-section'>
                        <span className="section-title">Current Production Status - Machines & Manual </span>
                    </Row>
                </Row>


                <Row className="section-container">
                    <Row>
                        <Col xs={12} sm={6} lg={6} xl={6} className="mb-4">
                            <TableContainer title="MACHINES" products={this.state.machineStatus}/>
                            {/*<GaugeContainer title="Machines Start Status" maxLog={this.state.start_maxLog} devices={this.state.device_start_data}/>*/}
                        </Col>
                        <Col xs={12} sm={6} lg={6} xl={6} className="mb-4">
                            <TableContainer title="MANUAL" products={this.state.manualStatus}/>
                            {/*<GaugeContainer title="Machines Stop Status" maxLog={this.state.stop_maxLog} devices={this.state.device_stop_data}/>*/}
                        </Col>
                    </Row>
                </Row>
            </div>
        );
    }

}

export default DashboardOverview;


const root = createRoot(document.getElementById('current-production-status'));
root.render(<DashboardOverview/>);