import React, {useState, useEffect, useRef} from 'react';
import {Button, Col} from "@themesberg/react-bootstrap";

const BottonGroup = (props) => {
    useEffect(() => {
    }, []);

    const routeChange = (subPath) => {
        let path = "/admin" + subPath;
        location.href = path;
    };

    return (
        <span className='date-picker-group'>
            <span>
                <a className="btn btn-success date-picker-button top-tab-button"
                   href={"/admin/single-product-analysis"}>
                    Single Product Analysis
                </a>
            </span>
            <span>
                <a className="btn btn-success date-picker-button top-tab-button"
                   href={"/admin/equipment-time"}>
                    Equipment vs Time
                </a>
            </span>
            <span>
                <a className="btn btn-success date-picker-button top-tab-button"
                   href={"/admin/lsc-utilisation"}>
                    LSC Utilisation
                </a>
            </span>
            <span>
                <a className="btn btn-success date-picker-button top-tab-button"
                   href={"/admin/current-production-status"}>
                    Current Production Status
                </a>
            </span>
            <span>
                <a className="btn btn-success date-picker-button top-tab-button"
                   href={"/admin/device-status"}>
                    Machines Status
                </a>
            </span>
            <span>
                <a className="btn btn-success top-tab-button"
                   href={"/admin/recipe-process-on-machines"}>
                    Recipes Process On Machines
                </a>
            </span>
        </span>
    );

};


export default BottonGroup;
