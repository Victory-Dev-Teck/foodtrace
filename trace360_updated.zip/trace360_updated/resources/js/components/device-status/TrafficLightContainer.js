import React, {useState, useEffect} from 'react';
import TrafficLight from 'react-trafficlight';
import {Card, CardHeader, CardBody} from "react-simple-card";
import "../../css/cardStyle.css";

const TrafficLightContainer = (props) => {

        const {machine_id, duration} = props.deviceStatus == undefined ?
            {
                machine_id: "Device Name",
                duration: "---"
            } : props.deviceStatus.duration == null ? {
                machine_id: props.deviceStatus.machine_id,
                duration: "---"
            } : {
                machine_id: props.deviceStatus.machine_id,
                duration: Math.floor(props.deviceStatus.duration)
            };

        const [redOn, setRedOn] = useState(true);
        const [yellowOn, setYellowOn] = useState(false);
        const [greenOn, setGreenOn] = useState(false);
        useEffect(() => {
            if (duration == "---") {
                setRedOn(true);
                setYellowOn(false);
                setGreenOn(false);
            } else {
                if (duration < 65) {
                    setRedOn(false);
                    setYellowOn(false);
                    setGreenOn(true);
                }
                else if (duration < 75) {
                    setRedOn(false);
                    setYellowOn(true);
                    setGreenOn(false);
                } else {
                    setRedOn(true);
                    setYellowOn(false);
                    setGreenOn(false);
                }
            }

        }, [props.deviceStatus]);
        return (
            <Card bgColor="#e2e8e8"
                  className="card-container traffic-light-container"
                // bgColor={(props.message.voltage === "--" ? '#aaaaaa' : isDangerous() ? '#c91112' : isWarning() ? '#ffb848' : '#28b779')}
            >
                <CardHeader>
                    <div className="props-title">
                        {machine_id}
                    </div>
                </CardHeader>
                <CardBody>
                    <TrafficLight
                        RedOn={redOn}
                        YellowOn={yellowOn}
                        GreenOn={greenOn}
                    />
                    <div className="props-duration">{duration} sec</div>
                </CardBody>
                {/* <CardFooter>
        <div onClick={() => handleClick(props.message.device_id, props.message.device_sn)}
          className=" col-md-12 col-xs-12 col-lg-12 col-xl-12 history-link">VIEW HISTORY
                    </div>
      </CardFooter> */}
            </Card>
        )
    }
;
export default TrafficLightContainer;
