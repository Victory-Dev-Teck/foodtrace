import React from "react";
import { createRoot } from 'react-dom/client';
import {RestDataSource} from '../../service/RestDataSource'
import {Col, Row, Button} from '@themesberg/react-bootstrap';
import '../../css/dashboard.css';
import "../../css/monthPickerStyle.css";
import DateRangePicker from '@wojtekmaj/react-daterange-picker';
import ButtonGroup from '../ButtonGroup';
import TrafficLightContainer from "./TrafficLightContainer";
import GaugeContainer from "./GaugeContainer";


class DashboardOverview extends React.Component {

    constructor(props) {
        super(props);
        this.dataSource = new RestDataSource(process.env.MIX_APP_URL, (err) => this.props.history.push('/error/${err}'));
        this.state = {
            dateRange1: [this.getMonday(), new Date()],
            height: 400,
            deviceStatus:[],
            start_maxLog:0,
            device_start_data:[],
            stop_maxLog:0,
            device_stop_data:[],

        };
    }

    /**Get the date of {agoMonth} ago from now. */
    getDateFrom(agoMonth) {
        let curDate = new Date();
        curDate.setMonth(curDate.getMonth() - agoMonth);
        return curDate;
    }

    /**
     * Convert Date time string to UTC datetime string.
     * @param dateStr
     * @param timeStr
     * @returns {string}
     */
    convertLocalTimeToUTCString (dateStr, timeStr) {
        let createTime = new Date(dateStr);
        let diff = createTime.getTimezoneOffset() * 60 * 1000;
        let timestamp = createTime.getTime() + diff;

        let diffMins = createTime.getTimezoneOffset();
        let time = timeStr.split(':');
        let hrs = parseInt(time[0]);
        let mins = parseInt(time[1]);
        let originMins = hrs * 60 + mins;
        let tempMins = originMins + diffMins;
        let convertedMins = 0;
        if (tempMins > 0) {
            convertedMins = tempMins;
        } else {
            convertedMins = 24 * 60 + tempMins;
            timestamp = timestamp - 24 * 60 * 60 * 1000;
        }
        let date = new Date(timestamp);
        let year = date.getFullYear();
        let month = ("0"+(date.getMonth() + 1)).substr(-2);
        let day = ("0"+date.getDate()).substr(-2);
        // let month = date.getMonth() + 1;
        // let day = date.getDate();
        let resultHrs = "0" + parseInt(convertedMins / 60);
        let resultMins = "0" + convertedMins % 60;
        let formattedTime = year + '-' + month + '-' + day + ' ' + resultHrs.substr(-2) + ':' + resultMins.substr(-2) + ":00";
        return formattedTime;
    };

    getMonday() {
        let d = new Date();
        let day = d.getDay(),
            diff = d.getDate() - day + (day == 0 ? -6:1); // adjust when day is sunday

        let monday= new Date(d.setDate(diff));
        let fromDate = monday.getFullYear() + "-" + ("0"+(monday.getMonth() + 1)).substr(-2) + "-" + ("0"+monday.getDate()).substr(-2);
        let dateFrom=new Date(fromDate);
        // let dateFrom=this.convertLocalTimeToUTCString(fromDate,"00:00:00");
        return dateFrom
    }
    getToday(){
        let d=new Date();
        let today=d.getFullYear() + "-" + ("0"+(d.getMonth() + 1)).substr(-2) + "-" + ("0"+d.getDate()).substr(-2);
        let todayFrom=new Date(today);
        return todayFrom;
    }


    componentDidMount() {
        this.refreshAll();
        this.interval = setInterval(() => this.refreshAll(), 50000);
    }

    componentWillUnmount() {
        clearInterval(this.interval);
    }


    refreshGauge(dateRange){
        this.setState({dateRange1: dateRange}, ()=>{

            console.log("dateRange----------", this.state.dateRange1);
            let request_data = {
                from: {
                    year: dateRange[0].getFullYear(),
                    month: dateRange[0].getMonth(),
                    day: dateRange[0].getDate()
                },
                to: {
                    year: dateRange[1].getFullYear(),
                    month: dateRange[1].getMonth(),
                    day: dateRange[1].getDate()
                }
            };

            this.dataSource.GetData("/dashboard/v1/device-online-status/start-time",
                data => {
                    this.setState({start_maxLog:data.max_log});
                    this.setState({device_start_data:data.dataset});
                }, request_data);

            this.dataSource.GetData("/dashboard/v1/device-online-status/stop-time",
                data => {
                    this.setState({stop_maxLog:data.max_log});
                    this.setState({device_stop_data:data.dataset});
                }, request_data);

        });
    }

    refreshTrafficLight() {
        this.dataSource.GetRequest("/dashboard/v1/device-online-status",
            data => {
                console.log(data);
                this.setState({deviceStatus: data});
            });
    }

    refreshAll(){
        this.refreshTrafficLight();
        this.refreshGauge(this.state.dateRange1);
    }

    render() {
        return (
            <div className="dashboard-container">

                <Row className="section-container">
                    <Row>
                        <ButtonGroup></ButtonGroup>
                    </Row>


                    <Row className='top-section'>
                        <span className="section-title">Machines Status</span>
                    </Row>

                    <Row className='top-section'>
                        <span className='date-picker-group'>
                            <span>
                                <Button variant="primary" className="mb-2 me-2 date-picker-button"
                                        onClick={() => this.refreshGauge([this.getMonday(), new Date()])}>
                                    This week so far: Monday to now
                                        </Button>
                            </span>
                            <span>
                                <Button variant="primary" className="mb-2 me-2 date-picker-button"
                                        onClick={() => this.refreshGauge([this.getToday(), new Date()])}>
                                    Today
                                        </Button>
                            </span>
                            <span>
                                <DateRangePicker
                                    calendarAriaLabel="Toggle calendar"
                                    clearAriaLabel="Clear value"
                                    rangeDivider="~"
                                    dayAriaLabel="Day"
                                    monthAriaLabel="Month"
                                    nativeInputAriaLabel="Date"
                                    clearIcon={null}
                                    onChange={(value) => this.refreshGauge(value)}
                                    value={this.state.dateRange1}
                                    yearAriaLabel="Year"
                                />
                            </span>
                        </span>
                    </Row>
                    {/*{for (var i = 0; i < selectedProfile.length; i++) }*/}

                    {this.state.deviceStatus.map((device, index) => {
                            return <Col key={index} xs={12} md={4} lg={2} xl={2} style={{padding: '0px 5px 0px 0px'}}>
                                <TrafficLightContainer deviceStatus={device}/>
                            </Col>
                        }
                    )}
                </Row>


                <Row className="section-container">
                    <Row>
                        <Col xs={12} sm={6} lg={6} xl={6} className="mb-4">
                            <GaugeContainer title="Machines Start Status" maxLog={this.state.start_maxLog} devices={this.state.device_start_data}/>
                        </Col>
                        <Col xs={12} sm={6} lg={6} xl={6} className="mb-4">
                            <GaugeContainer title="Machines Stop Status" maxLog={this.state.stop_maxLog} devices={this.state.device_stop_data}/>
                        </Col>
                    </Row>
                </Row>
            </div>
        );
    }

}

export default DashboardOverview;


const root = createRoot(document.getElementById('device-status-dashboard'));
root.render(<DashboardOverview/>);