import React, {useState, useEffect, useRef } from 'react';
import {Card, CardBody, CardHeader} from "react-simple-card";
import {Col} from "@themesberg/react-bootstrap";
import Gauge from "./Gauge";


const GaugeContainer = (props) => {
    const colRef = useRef();
    const [value, setValue] = useState(0); // integer state

    useEffect(()=>{
        let interval = setInterval(() => refreshAll(), 2000);
        return () => {
            clearInterval(interval);
        };
    },[]);

    function refreshAll() {
        setValue(value => value + 1);
    }
    return (
        <Card style={{margin: '20px, 0px, 20px, 0px'}}
              className="card-container" bgColor="#e2e8e8"
        >
            <CardHeader>
                <div className="props-title">
                    {props.title}
                </div>
            </CardHeader>
            <CardBody>
                {props.devices.map((item, index) => {
                    return <Col ref={colRef} key={'top_column_' + item.id + item.name} xs={12} md={4} lg={3} xl={1}
                            >
                        <Gauge deviceStartState={item} max_log={props.maxLog} pWidth={colRef.current==undefined?150:colRef.current.offsetWidth<120?120:colRef.current.offsetWidth}/>
                    </Col>
                        // return index % 4 == 0 && window.innerWidth >= 1920 ?
                        //     <Col key={'top_column_' + item.id + item.name} xs={12} md={4} lg={4} xl={4} className="mb-4"
                        //          style={{padding: '0px 0px 0px 0px'}}>
                        //         {props.devices.slice(index, index + 4).map((device, index1) =>
                        //             <Col key={device.name} xs={12} md={3} lg={3} xl={3} className="mb-4">
                        //                 <Gauge deviceStartState={device} max_log={props.maxLog}/>
                        //             </Col>
                        //         )}
                        //     </Col>
                        //     : index % 3 == 0 && window.innerWidth >= 1520 && window.innerWidth < 1920 ?
                        //         <Col key={'top_column_' + item.id + item.name} xs={12} md={4} lg={4} xl={4}
                        //              className="mb-4"
                        //              style={{padding: '0px 0px 0px 0px'}}>
                        //             {props.devices.slice(index, index + 3).map((device, index1) =>
                        //                 <Col key={device.name} xs={12} md={4} lg={4} xl={4} className="mb-4">
                        //                     <Gauge deviceStartState={device} max_log={props.maxLog}/>
                        //                 </Col>
                        //             )}
                        //         </Col>
                        //         : index % 2 == 0 && window.innerWidth >= 1024 && window.innerWidth < 1520 ?
                        //             <Col key={'top_column_' + item.id + item.name} xs={12} md={4} lg={4} xl={4}
                        //                  className="mb-4"
                        //                  style={{padding: '0px 0px 0px 0px'}}>
                        //                 {props.devices.slice(index, index + 2).map((device, index1) =>
                        //                     <Col key={device.name} xs={12} md={6} lg={6} xl={6} className="mb-4">
                        //                         <Gauge deviceStartState={device} max_log={props.maxLog}/>
                        //                     </Col>
                        //                 )}
                        //             </Col>
                        //             : index % 1 == 0 && window.innerWidth >= 800 && window.innerWidth < 1024 ?
                        //                 <Col key={'top_column_' + item.id + item.name} xs={12} md={4} lg={4} xl={4}
                        //                      className="mb-4"
                        //                      style={{padding: '0px 0px 0px 0px'}}>
                        //                     {props.devices.slice(index, index + 1).map((device, index1) =>
                        //                         <Col key={device.name} xs={12} md={12} lg={12} xl={12}
                        //                              className="mb-4">
                        //                             <Gauge deviceStartState={device} max_log={props.maxLog}/>
                        //                         </Col>
                        //                     )}
                        //                 </Col>
                        //                 : index % 1 == 0 && window.innerWidth < 800 ?
                        //                     <Col key={'top_column_' + item.id + item.name} xs={12} md={12} lg={12}
                        //                          xl={12}
                        //                          className="mb-4">
                        //                         <Gauge deviceStartState={item} max_log={props.maxLog}/>
                        //                     </Col> : null
                    }
                )}
            </CardBody>
        </Card>

    );

};


export default GaugeContainer;
