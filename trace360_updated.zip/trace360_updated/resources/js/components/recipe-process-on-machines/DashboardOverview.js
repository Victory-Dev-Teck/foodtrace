import React from "react";
import {createRoot} from 'react-dom/client';
import {RestDataSource} from '../../service/RestDataSource'
import {Col, Row, Button} from '@themesberg/react-bootstrap';
import '../../css/dashboard.css';
import "../../css/monthPickerStyle.css";
import ButtonGroup from "../ButtonGroup";
import Select from 'react-select';
import DateRangePicker from "@wojtekmaj/react-daterange-picker";
import MachineProcessChart from "./MachineProcessChart";
import TableContainer from "./TableContainer";


const customControlStyles = base => ({
    ...base,
    marginTop:5,
    height: 33,
    minHeight: 33,
});

class DashboardOverview extends React.Component {

    constructor(props) {
        super(props);
        this.dataSource = new RestDataSource(process.env.MIX_APP_URL, (err) => this.props.history.push('/error/${err}'));
        this.state = {
            dateRange1: [this.getMonday(), new Date()],
            lscOptions: [],
            selectedLsc: {value: 0, label: "All"},
            recipesOptions: [],
            selectedRecipe: {value: 0, label: "All"},
            userOptions: [],
            selectedUser: {value: 0, label: "All"},
        };

    };

    getMonday() {
        let d = new Date();
        let day = d.getDay(),
            diff = d.getDate() - day + (day == 0 ? -6 : 1); // adjust when day is sunday

        let monday = new Date(d.setDate(diff));
        let fromDate = monday.getFullYear() + "-" + ("0" + (monday.getMonth() + 1)).substr(-2) + "-" + ("0" + monday.getDate()).substr(-2);
        let dateFrom = new Date(fromDate);
        // let dateFrom=this.convertLocalTimeToUTCString(fromDate,"00:00:00");
        return dateFrom
    }

    getToday() {
        let d = new Date();
        let today = d.getFullYear() + "-" + ("0" + (d.getMonth() + 1)).substr(-2) + "-" + ("0" + d.getDate()).substr(-2);
        let todayFrom = new Date(today);
        return todayFrom;
    }

    setRecipesOption(option) {
        this.setState({selectedRecipe: option}, () => {
        });
    }

    setLscOption(option) {
        this.setState({selectedLsc: option}, () => {
        });
    }
    setUserOption(option) {
        this.setState({selectedUser: option}, () => {
        });
    }

    componentDidMount() {
        this.refresh();
        // this.interval = setInterval(() => this.refreshAll(), 50000);
    }

    refresh() {

        this.dataSource.GetRequest("/dashboard/v1/lsc-devices",
            data => {

                this.setState({lscOptions: data});
            });

        this.dataSource.GetRequest("/dashboard/v1/recipes",
            data => {
                this.setState({recipesOptions: data});
            });
        this.dataSource.GetRequest("/dashboard/v1/users?role_id=8",
            data => {
                this.setState({userOptions: data});
            });
        // this.dataSource.GetRequest("/dashboard/v1/double-machines",
        //     data => {
        //         this.setState({doubleMachines: data});
        //     });
    }

    render() {
        return (
            <div className="dashboard-container">

                <Row className="section-container">
                    <Row>
                        <ButtonGroup></ButtonGroup>
                    </Row>
                    <Row className='top-section'>
                        <span className="section-title">Recipes Process On Machines</span>
                    </Row>
                    <div className="setting-row-container-short">
                        {/*<div className="filter-section">*/}
                            <span className={"filter-section select-title"}>User
                            </span>
                            <span>
                                <Select
                                    className="short-select-box"
                                    defaultValue={this.state.selectedUser}
                                    onChange={(option) => this.setUserOption(option)}
                                    options={this.state.userOptions}
                                    styles={{control: customControlStyles}}
                                />
                            </span>
                            <span className={"select-title"}>Log Station Clients
                            </span>
                            <span>
                                <Select
                                    className="short-select-box"
                                    defaultValue={this.state.selectedLsc}
                                    onChange={(option) => this.setLscOption(option)}
                                    options={this.state.lscOptions}
                                    styles={{control: customControlStyles}}
                                />
                            </span>
                            <span className={"select-title"}>Recipes
                            </span>
                            <span>
                                <Select
                                    className="select-box"
                                    defaultValue={this.state.selectedRecipe}
                                    onChange={(option) => this.setRecipesOption(option)}
                                    options={this.state.recipesOptions}
                                    styles={{control: customControlStyles}}
                                />
                            </span>
                        {/*</div>*/}
                        <div className={"date-picker-section"}>
                            <span className='date-picker-group'>

                            <span>
                                <Button variant="primary" className="mb-2 me-2 date-picker-button"
                                        onClick={() => this.setState({dateRange1: [this.getToday(), new Date()]})}>
                                    Today
                                        </Button>
                            </span>
                            <span>
                                <Button variant="primary" className="mb-2 me-2 date-picker-button"
                                        onClick={() => this.setState({dateRange1: [this.getMonday(), new Date()]})}>
                                    This week so far: Monday to now
                                        </Button>
                            </span>
                            <span>
                                <DateRangePicker
                                    calendarAriaLabel="Toggle calendar"
                                    clearAriaLabel="Clear value"
                                    rangeDivider="~"
                                    dayAriaLabel="Day"
                                    monthAriaLabel="Month"
                                    nativeInputAriaLabel="Date"
                                    clearIcon={null}
                                    onChange={(value) => this.setState({dateRange1: value})}
                                    value={this.state.dateRange1}
                                    yearAriaLabel="Year"
                                />
                            </span>
                        </span>
                        </div>
                    </div>
                </Row>


                <Row>
                    <Col xs={12} sm={12} lg={12} xl={12}>
                        <MachineProcessChart dataSource={this.dataSource} dateRange={this.state.dateRange1}
                                             user_id={this.state.selectedUser} lsc_id={this.state.selectedLsc} recipe_id={this.state.selectedRecipe} machine_id={1} title="Single Machines" height="500px"/>
                    </Col>
                    <Col xs={12} sm={12} lg={12} xl={12}>
                        <MachineProcessChart dataSource={this.dataSource} dateRange={this.state.dateRange1}
                                             user_id={this.state.selectedUser} lsc_id={this.state.selectedLsc} recipe_id={this.state.selectedRecipe} machine_id={2} title="Multiple Machines" height="500px"/>
                    </Col>
                </Row>

                <Row>
                    <Col xs={12} sm={6} lg={6} xl={6} className="mb-4">
                        <TableContainer dataSource={this.dataSource} dateRange={this.state.dateRange1}
                                        user_id={this.state.selectedUser} lsc_id={this.state.selectedLsc} recipe_id={this.state.selectedRecipe} machine_id={1} title="Equip Usage Table (Single)" />
                    </Col>
                    <Col xs={12} sm={6} lg={6} xl={6} className="mb-4">
                        <TableContainer dataSource={this.dataSource} dateRange={this.state.dateRange1}
                                        user_id={this.state.selectedUser} lsc_id={this.state.selectedLsc} recipe_id={this.state.selectedRecipe} machine_id={2} title="Equip Usage Table (Multiple)" products={2}/>
                    </Col>
                </Row>
            </div>
        );
    }

}

export default DashboardOverview;

const root = createRoot(document.getElementById('recipe-process-on-machines'));
root.render(<DashboardOverview/>);