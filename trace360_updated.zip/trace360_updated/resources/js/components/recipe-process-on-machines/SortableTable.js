import React from 'react'
import ReactTable from 'react-table-v6'
import 'react-table-v6/react-table.css'


const SortableTable = (props) => {
    function secondsToDhms(seconds) {
        seconds = Number(seconds);
        var d = Math.floor(seconds / (3600 * 24));
        var h = Math.floor(seconds % (3600 * 24) / 3600);
        var m = Math.floor(seconds % 3600 / 60);
        var s = Math.floor(seconds % 60);

        var dDisplay = d > 0 ? d + (d == 1 ? " day " : " days ") : "";
        var hDisplay = h > 0 ? h + (h == 1 ? " hour " : " hours ") : "";
        var mDisplay = m > 0 ? m + (m == 1 ? " min " : " mins ") : "";
        var sDisplay = s > 0 ? s + (s == 1 ? " sec" : " secs") : "";
        return dDisplay + hDisplay + mDisplay + sDisplay;
    }

    const columns = [
        {
            Header: 'Device',
            accessor: 'Device', // String-based value accessors!
            maxWidth: undefined, // A maximum width for this column.
            style: {
                color: "#777",
                border: "1px solid #ccc"
            }, // Set the style of the `td` element of the column
            headerClassName: '', // Set the classname of the `th` element of the column
            headerStyle: {
                color: "#33A2E5"
            },
        },
        {
            Header: 'Recipe',
            accessor:
                'Recipes',
            style: {
                color: "#777",
                border: "1px solid #ccc"
            },
            // Header & HeaderGroup Options
            headerClassName: '', // Set the classname of the `th` element of the column
            headerStyle: {
                color: "#33A2E5"
            },
        }
        ,
        {
            Header: 'Start Time',
            accessor:
                'StartTime',
            style: {
                color: "#777",
                border: "1px solid #ccc"
            },
            // Header & HeaderGroup Options
            headerClassName: '', // Set the classname of the `th` element of the column
            headerStyle: {
                color: "#33A2E5"
            },
        }
        ,
        {
            Header: 'End Time',
            accessor:
                'EndTime',
            style: {
                color: "#777",
                border: "1px solid #ccc"
            },
            // Header & HeaderGroup Options
            headerClassName: '', // Set the classname of the `th` element of the column
            headerStyle: {
                color: "#33A2E5"
            },
        }
        ,
        {
            Header: 'Duration',
            accessor:
                'minutes',
            Cell: ({row}) => {
                return <div>{secondsToDhms(row.minutes)}</div>
            },

            style: {
                color: "#777",
                border: "1px solid #ccc"
            },
            width: 210,
            // Header & HeaderGroup Options
            headerClassName: '', // Set the classname of the `th` element of the column
            headerStyle:
                {
                    color: "#33A2E5"
                }
            ,
        }
    ];
    return <ReactTable
        data={props.products}
        columns={columns}
        showPagination={false}
        pageSize={props.products.length > 15 ? props.products.length : 15}
        style={{
            height: "600px", // This will force the table body to overflow and scroll, since there is not enough room

        }}
    />
};



export default SortableTable;
