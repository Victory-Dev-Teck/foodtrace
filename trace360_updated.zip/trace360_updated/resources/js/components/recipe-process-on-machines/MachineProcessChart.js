import React, {useState, useEffect} from 'react';
import ReactApexChart from 'react-apexcharts';

const MachineProcessChart = (props) => {
        const [series, setSeries] = useState([{
            "name": "",
            "data": [
                {
                    x: "",
                    y: [
                        new Date('2020-01-01').getTime(),
                        new Date('2020-01-02').getTime()
                    ],
                    minutes: 1
                },
            ]
        }]);
        const [options, setOptions] = useState({

            chart: {
                group: 'social',
                type: 'rangeBar',
                // background: "#141619",
                // foreColor: '#ffffff',
                toolbar: {
                    show: true,
                    offsetX: 0,
                    offsetY: 0,
                    tools: {
                        download: false,
                        selection: true,
                        zoom: true,
                        zoomin: false,
                        zoomout: false,
                        pan: true,
                        // reset: true | '<img src="/static/icons/reset.png" width="20">',
                        customIcons: []
                    },
                    export: {
                        csv: {
                            filename: undefined,
                            columnDelimiter: ',',
                            headerCategory: 'category',
                            headerValue: 'value',
                            dateFormatter(timestamp) {
                                return new Date(timestamp).toDateString()
                            }
                        },
                        svg: {
                            filename: undefined,
                        },
                        png: {
                            filename: undefined,
                        }
                    },
                    autoSelected: 'zoom'
                },
            },
            title: {
                text: props.title,
                align: 'center',
                margin: 10,
                offsetX: 0,
                offsetY: 0,
                floating: false,
                style: {
                    fontSize: '14px',
                    fontWeight: 'bold',
                    fontFamily: undefined,
                    color: '#5c5c5c'
                },
            },
            legend: {
                show: false,
            },
            grid: {
                show: true,
                borderColor: '#ccc',
                strokeDashArray: 0,
                position: 'back',
                xaxis: {
                    lines: {
                        show: true
                    }
                },
                yaxis: {
                    lines: {
                        show: true
                    }
                }
            },
            plotOptions: {
                bar: {
                    horizontal: true,
                    barHeight: '80%',
                    rangeBarGroupRows: true
                }
            },
            xaxis: {
                type: 'datetime',
                min: props.dateRange[0].getTime(),
                max: props.dateRange[1].getTime(),
                axisBorder: {
                    show: true,
                    color: '#78909C',
                    height: 1,
                    width: '100%',
                    offsetX: 0,
                    offsetY: 0
                },
                axisTicks: {
                    show: true,
                    borderType: 'solid',
                    color: '#78909C',
                    height: 6,
                    offsetX: 0,
                    offsetY: 0
                },
            },
            yaxis: {
                axisBorder: {
                    show: true,
                    color: '#78909C',
                    height: '100%',
                    width: 1,
                    offsetX: 0,
                    offsetY: 0
                },
                axisTicks: {
                    show: true,
                    borderType: 'solid',
                    color: '#78909C',
                    width: 6,
                    offsetX: 0,
                    offsetY: 0
                },
            },
            tooltip: {
                y: {
                    formatter: function (value, {series, seriesIndex, dataPointIndex, w}) {
                        var data = w.globals.initialSeries[seriesIndex].data[dataPointIndex];
                        return '<div>' +
                            '<div><b>' + value + '</b></div>' +
                            '<div><b>' + secondsToDhms(data.minutes) + '</b></div>' +
                            // '<li><b>Duration</b>: \'' + data.minutes + '\'</li>'
                            '</div>'
                    },
                },

            }


        });

        function secondsToDhms(seconds) {
            seconds = Number(seconds);
            var d = Math.floor(seconds / (3600 * 24));
            var h = Math.floor(seconds % (3600 * 24) / 3600);
            var m = Math.floor(seconds % 3600 / 60);
            var s = Math.floor(seconds % 60);

            var dDisplay = d > 0 ? d + (d == 1 ? " day " : " days ") : "";
            var hDisplay = h > 0 ? h + (h == 1 ? " hour " : " hours ") : "";
            var mDisplay = m > 0 ? m + (m == 1 ? " min " : " mins ") : "";
            var sDisplay = s > 0 ? s + (s == 1 ? " sec" : " secs") : "";
            return dDisplay + hDisplay + mDisplay + sDisplay;
        }

        useEffect(() => {
                setOptions(prevOption => ({
                        ...prevOption, xaxis: {
                            type: 'datetime',
                            min: props.dateRange[0].getTime(),
                            max: props.dateRange[1].getTime(),
                        }
                    }
                ));

                let request_data = {
                    from: {
                        year: props.dateRange[0].getFullYear(),
                        month: props.dateRange[0].getMonth(),
                        day: props.dateRange[0].getDate()
                    },
                    to: {
                        year: props.dateRange[1].getFullYear(),
                        month: props.dateRange[1].getMonth(),
                        day: props.dateRange[1].getDate()
                    }
                };

                let newSeries = [];
                if (props.machine_id == 1) {
                    props.dataSource.PostRequest("/dashboard/v1/recipe-process-single-machines?user_id=" + props.user_id.value + "&lsc_id=" + props.lsc_id.value + "&recipe_id=" + props.recipe_id.value,
                        equip_data => {
                            let prevRecipe = "";
                            equip_data.map(item => {
                                if (item.Recipes == prevRecipe) {
                                    let newRecipe = {
                                        x: item.Text,
                                        y: [
                                            new Date(item.StartTime).getTime(),
                                            new Date(item.EndTime).getTime()
                                        ],
                                        minutes: item.minutes
                                    };
                                    newSeries[newSeries.length - 1].data.push(newRecipe);
                                } else {
                                    let newEquip = {
                                        "name": item.Recipes,
                                        "data": [
                                            {
                                                x: item.Text,
                                                y: [
                                                    new Date(item.StartTime).getTime(),
                                                    new Date(item.EndTime).getTime()
                                                ],
                                                minutes: item.minutes
                                            },
                                        ]
                                    };
                                    newSeries.push(newEquip);
                                }
                                prevRecipe = item.Recipes;

                            });

                            props.dataSource.PostRequest("/dashboard/v1/unlogged-machines?machine_type=" + props.machine_id,
                                equip_data => {
                                    equip_data.map(item => {
                                        let newEquip = {
                                            "name": "",
                                            "data": [
                                                {
                                                    x: item.metric,
                                                    y: [
                                                        new Date('2020-01-01').getTime(),
                                                        new Date('2020-01-02').getTime()
                                                    ],
                                                    minutes: 86400
                                                },
                                            ]
                                        };
                                        newSeries.push(newEquip);
                                    });

                                    if (newSeries.length == 0) {
                                        let newEquip = {
                                            "name": "",
                                            "data": [
                                                {
                                                    x: "",
                                                    y: [
                                                        new Date('2020-01-01').getTime(),
                                                        new Date('2020-01-02').getTime()
                                                    ],
                                                    minutes: 1
                                                },
                                            ]
                                        };
                                        newSeries.push(newEquip);
                                    }
                                    setSeries(newSeries);

                                }, request_data);

                        }, request_data);
                }
                else {
                    let newSeries = [];
                    props.dataSource.PostRequest("/dashboard/v1/recipe-process-multiple-machines?user_id=" + props.user_id.value + "&lsc_id=" + props.lsc_id.value + "&recipe_id=" + props.recipe_id.value,
                        equip_data => {
                            equip_data.map(item => {
                                let newEquip = {
                                    "name": item.Recipes,
                                    "data": [
                                        {
                                            x: item.Text,
                                            y: [
                                                new Date(item.StartTime).getTime(),
                                                new Date(item.EndTime).getTime()
                                            ],
                                            minutes: item.minutes
                                        },
                                    ]
                                };
                                newSeries.push(newEquip);
                            });
                            props.dataSource.PostRequest("/dashboard/v1/unlogged-machines?machine_type=" + props.machine_id,
                                equip_data => {
                                    equip_data.map(item => {
                                        let newEquip = {
                                            "name": "",
                                            "data": [
                                                {
                                                    x: item.metric,
                                                    y: [
                                                        new Date('2020-01-01').getTime(),
                                                        new Date('2020-01-02').getTime()
                                                    ],
                                                    minutes: 86400
                                                },
                                            ]
                                        };
                                        newSeries.push(newEquip);
                                    });

                                    if (newSeries.length == 0) {
                                        let newEquip = {
                                            "name": "",
                                            "data": [
                                                {
                                                    x: "",
                                                    y: [
                                                        new Date('2020-01-01').getTime(),
                                                        new Date('2020-01-02').getTime()
                                                    ],
                                                    minutes: 1
                                                },
                                            ]
                                        };
                                        newSeries.push(newEquip);
                                    }
                                    setSeries(newSeries);

                                }, request_data);
                        }, request_data);
                }
            },
            [props.dateRange, props.user_id, props.lsc_id, props.recipe_id]
        )
        ;

        return (
            <div id="chart">
                <ReactApexChart options={options} series={series} type="rangeBar" height={props.height}/>
            </div>

        );
    }
;

export default MachineProcessChart;