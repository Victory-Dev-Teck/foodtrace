import React, {useState, useEffect, useRef } from 'react';
import {Card, CardBody, CardHeader} from "react-simple-card";
import SortableTable from "./SortableTable";
import "../../css/cardStyle.css"
import "./table.css"

const TableContainer = (props) => {
    const [series, setSeries] = useState([]);

    useEffect(() => {
            let request_data = {
                from: {
                    year: props.dateRange[0].getFullYear(),
                    month: props.dateRange[0].getMonth(),
                    day: props.dateRange[0].getDate()
                },
                to: {
                    year: props.dateRange[1].getFullYear(),
                    month: props.dateRange[1].getMonth(),
                    day: props.dateRange[1].getDate()
                }
            };

            if (props.machine_id == 1) {
                props.dataSource.PostRequest("/dashboard/v1/recipe-process-single-machines?user_id=" + props.user_id.value + "&lsc_id=" + props.lsc_id.value + "&recipe_id=" + props.recipe_id.value,
                    equip_data => {
                    setSeries(equip_data);
                    }, request_data);
            }
            else {
                props.dataSource.PostRequest("/dashboard/v1/recipe-process-multiple-machines?user_id=" + props.user_id.value + "&lsc_id=" + props.lsc_id.value + "&recipe_id=" + props.recipe_id.value,
                    equip_data => {
                    setSeries(equip_data);
                    }, request_data);
            }

        },
        [props.dateRange, props.user_id, props.lsc_id, props.recipe_id]
    )
    ;


    return (
        <Card style={{margin: '20px, 0px, 20px, 0px'}}
              className="card-container" bgColor="#e2e8e8"
        >
            <CardHeader>
                <div className="props-title">
                    {props.title}
                </div>
            </CardHeader>
            <CardBody>
                <SortableTable products={series}/>
            </CardBody>
        </Card>

    );

};


export default TableContainer;
