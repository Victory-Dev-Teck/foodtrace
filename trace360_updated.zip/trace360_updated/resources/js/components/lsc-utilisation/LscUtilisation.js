import React, {useState, useEffect} from 'react';
import ReactApexChart from "react-apexcharts";


const LscUtilisation = (props) => {

    const [series, setSeries] = useState([]);


    const [options, setOptions] = useState({
        title: {
            text: props.title,
            align: 'center',
            margin: 20,
            offsetX: 0,
            offsetY: 0,
            floating: false,
            style: {
                fontSize: '14px',
                fontWeight: 'bold',
                // fontFamily:  undefined,
                color: '#526069'
            },
        },
        chart: {
            type: 'scatter',
            // background: "#141619",
            // foreColor: '#ffffff',
            toolbar: {
                show: false,
                offsetX: 0,
                offsetY: 0,
                tools: {
                    download: false,
                    selection: true,
                    zoom: true,
                    zoomin: false,
                    zoomout: false,
                    pan: true,
                    // reset: true | '<img src="/static/icons/reset.png" width="20">',
                    customIcons: []
                },
                export: {
                    csv: {
                        filename: undefined,
                        columnDelimiter: ',',
                        headerCategory: 'category',
                        headerValue: 'value',
                        dateFormatter(timestamp) {
                            return new Date(timestamp).toDateString()
                        }
                    },
                    svg: {
                        filename: undefined,
                    },
                    png: {
                        filename: undefined,
                    }
                },
                autoSelected: 'selection'
            },
        },


        legend: {
            show: false,
        },

        markers: {
            shape: "rect",
            width: 30,
            height: 15,
        },
        dataLabels: {
            enabled: false
        },
        grid: {
            xaxis: {
                lines: {
                    show: false
                }
            },
            yaxis: {
                lines: {
                    show: false
                }
            },
        },
        xaxis: {
            type: 'datetime',
            min: props.dateRange[0].getTime(),
            max: props.dateRange[1].getTime(),
            axisBorder: {
                show: true,
                color: '#78909C',
                height: 1,
                width: '100%',
                offsetX: 0,
                offsetY: 0
            },
            axisTicks: {
                show: true,
                borderType: 'solid',
                color: '#78909C',
                height: 6,
                offsetX: 0,
                offsetY: 0
            },
        },
        yaxis: {
            min: 0,
            max: 24,
            tickAmount: 24,
            reversed: true,
            labels: {
                formatter: (value) => {
                    return ("0" + value + ":00").substr(-5);
                }
            },
            axisBorder: {
                show: true,
                color: '#78909C',
                height: '100%',
                width: 1,
                offsetX: 0,
                offsetY: 0
            },
            axisTicks: {
                show: true,
                borderType: 'solid',
                color: '#78909C',
                width: 6,
                offsetX: 0,
                offsetY: 0
            },
        }
    });


    useEffect(() => {

        let request_data = {
            from: {
                year: props.dateRange[0].getFullYear(),
                month: props.dateRange[0].getMonth(),
                day: props.dateRange[0].getDate()
            },
            to: {
                year: props.dateRange[1].getFullYear(),
                month: props.dateRange[1].getMonth(),
                day: props.dateRange[1].getDate()
            }
        };

        props.dataSource.PostRequest("/dashboard/v1/lsc-utilisation?lsc_id=" + props.lsc_id + "&status=" + props.status,
            data => {
                setSeries(data);
            }, request_data);

        let selectedDays=(props.dateRange[1].getTime()-props.dateRange[0].getTime())/(24*3600000);
        setOptions(prevOptions => ({
            ...prevOptions, xaxis: {
                type: 'datetime',
                min: props.dateRange[0].getTime(),
                max: props.dateRange[1].getTime(),
            }
        }));
        setOptions(prevOptions => ({
            ...prevOptions, markers: {
                shape: "rect",
                width: 600/selectedDays,
                height: 15,
            }
        }));

    }, [props.dateRange, props.lsc_id]);
    return (
        <div id="chart">
            <ReactApexChart options={options} series={series} type="scatter" height={500}/>
        </div>
    );
};


export default LscUtilisation;