import React, {useState, useEffect, useRef} from 'react';
import {Card, CardBody, CardHeader} from "react-simple-card";
import {Col} from "@themesberg/react-bootstrap";
import Gauge from "./Gauge";
import "../../css/cardStyle.css";


const GaugeContainer = (props) => {
    const colRef = useRef();
    const [startCnt, setStartCnt] = useState(0);
    const [endCnt, setEndCnt] = useState(0);

    const [value, setValue] = useState(0); // integer state

    useEffect(()=>{
        let interval = setInterval(() => refreshAll(), 2000);
        return () => {
            clearInterval(interval);
        };
    },[]);

    function refreshAll() {
        setValue(value => value + 1);
    }
    useEffect(() => {

        let request_data = {
            from: {
                year: props.dateRange[0].getFullYear(),
                month: props.dateRange[0].getMonth(),
                day: props.dateRange[0].getDate()
            },
            to: {
                year: props.dateRange[1].getFullYear(),
                month: props.dateRange[1].getMonth(),
                day: props.dateRange[1].getDate()
            }
        };

        props.dataSource.PostRequest("/dashboard/v1/lsc-use-counts?lsc_id=" + props.lsc_id,
            data => {
                if (data.length > 0) {
                    data.map((item) => {
                        if (item.log_action == 1) {
                            setStartCnt(item.count);
                        } else if (item.log_action == 2) {
                            setEndCnt(item.count);
                        }
                    })
                }else {
                    setStartCnt(0);
                    setEndCnt(0);
                }
            },
            request_data
        );
    }, [props.dateRange, props.lsc_id]);


    return (
        <Card style={{margin: '20px, 0px, 20px, 0px'}}
              className="card-container" bgColor="#e2e8e8"
        >
            <CardHeader>
                <div className="props-title">
                    {props.title}
                </div>
            </CardHeader>
            <CardBody>
                <Col ref={colRef}  xs={12} md={6} lg={6} xl={6}>
                    <Gauge status="Start" count={startCnt} max_log={startCnt>100?startCnt:100}
                           pWidth={colRef.current == undefined ? 200 : colRef.current.offsetWidth/2 < 200 ? 200 : colRef.current.offsetWidth/2}/>
                </Col>

                <Col ref={colRef} xs={12} md={6} lg={6} xl={6}>
                    <Gauge status="Stop" count={endCnt} max_log={endCnt>100?endCnt:100}
                           pWidth={colRef.current == undefined ? 200 : colRef.current.offsetWidth/2 < 200 ? 200 : colRef.current.offsetWidth/2}/>
                </Col>
            </CardBody>
        </Card>

    );

};


export default GaugeContainer;
