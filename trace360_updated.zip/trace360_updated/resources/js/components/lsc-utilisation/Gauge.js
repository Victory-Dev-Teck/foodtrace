import React, {useState, useEffect} from 'react';
import ReactApexChart from "react-apexcharts";


const Gauge = (props) => {
    const [options, setOptions] = useState(
        {
            chart: {
                type: 'radialBar',
                toolbar: {
                    show: false
                },
            },
            colors: [getHexColor(props.count)],
            plotOptions: {
                radialBar: {
                    startAngle: -120,
                    endAngle: 120,
                    hollow: {
                        margin: 0,
                        size: '50%',
                        background: 'transparent',
                        image: undefined,
                        imageOffsetX: 0,
                        imageOffsetY: 0,
                        position: 'front',
                        dropShadow: {
                            enabled: true,
                            top: 3,
                            left: 0,
                            blur: 3,
                            opacity: 0.24
                        }
                    },
                    track: {
                        background: '#2F2F2F',
                        strokeWidth: '85%',
                        margin: 0, // margin is in pixels
                        dropShadow: {
                            enabled: true,
                            top: -3,
                            left: 0,
                            blur: 4,
                            opacity: 0.35
                        }
                    },

                    dataLabels: {
                        show: true,
                        name: {
                            show: false,
                            offsetY: 40,
                            color: '#c7d0d9',
                            fontSize: '11px'
                        },
                        value: {
                            show: true,
                            formatter: (val) => labelFormatter(val),
                            color: getTextColor(props.count),
                            // fontSize: '16px',
                            fontSize: props.pWidth/10+'px',
                            offsetY: 5,
                        }
                    }
                }
            },
            fill: {
                type: 'gradient',
                gradient: {
                    shade: 'dark',
                    type: 'horizontal',
                    shadeIntensity: 0.5,
                    // gradientToColors: ['#ABE5A1'],
                    inverseColors: false,
                    opacityFrom: 1,
                    opacityTo: 1,
                    stops: [0, 100]
                }
            },
            stroke: {
                lineCap: 'round'
            },
            // labels: [props.count+" Time"],
        },
    );


    useEffect(() => {
        setOptions(prevOptions => ({
            ...prevOptions,
            colors: [getHexColor(props.count)]
        }));
        setOptions(prevOptions => ({
            ...prevOptions, plotOptions: {
                ...prevOptions.plotOptions, radialBar: {
                    ...prevOptions.plotOptions.radialBar, dataLabels: {
                        ...prevOptions.plotOptions.radialBar.dataLabels, value: {
                            formatter: (val) => labelFormatter(val),
                            show: true,
                            color: getTextColor(props.count),
                            fontSize: props.pWidth/10+'px',
                            offsetY: 5,
                        }
                    }
                }
            }
        }));


    }, [props.count, props.max_log, props.pWidth]);

    function labelFormatter(val) {
        let log_times = Math.round(val * props.max_log / 100);
        return log_times + " Time";
    }

    function valueFormatter() {
        let value_percent = props.max_log == 0 ? 0 : (100 * props.count / props.max_log);
        return value_percent;
    }

    function getTextColor(count) {
        if (count === 0) {
            return "#F2495C";
        }

        let startHex = "#FFB357";
        let endHex = "#56A64B";
        let steps = props.max_log;

        let sDec = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(startHex),
            eDec = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(endHex);
        if (sDec && eDec) {
            let r_s = parseInt(sDec[1], 16);
            let g_s = parseInt(sDec[2], 16);
            let b_s = parseInt(sDec[3], 16);

            let r_e = parseInt(eDec[1], 16);
            let g_e = parseInt(eDec[2], 16);
            let b_e = parseInt(eDec[3], 16);

            let r_final = interpolate(r_s, r_e, steps, count);
            let g_final = interpolate(g_s, g_e, steps, count);
            let b_final = interpolate(b_s, b_e, steps, count);

            return "#" + ((1 << 24) + (r_final << 16) + (g_final << 8) + b_final).toString(16).slice(1);
        }
        return null;
    }

    function getHexColor(count) {

        if (count === 0) {
            return "#2F2F2F";
        }
        let startHex = "#FFB357";
        let endHex = "#56A64B";
        let steps = props.max_log;

        let sDec = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(startHex),
            eDec = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(endHex);
        if (sDec && eDec) {
            let r_s = parseInt(sDec[1], 16);
            let g_s = parseInt(sDec[2], 16);
            let b_s = parseInt(sDec[3], 16);

            let r_e = parseInt(eDec[1], 16);
            let g_e = parseInt(eDec[2], 16);
            let b_e = parseInt(eDec[3], 16);

            let r_final = interpolate(r_s, r_e, steps, count);
            let g_final = interpolate(g_s, g_e, steps, count);
            let b_final = interpolate(b_s, b_e, steps, count);

            return "#" + ((1 << 24) + (r_final << 16) + (g_final << 8) + b_final).toString(16).slice(1);
        }
        return null;
    }

    function interpolate(start, end, steps, count) {
        let s = start,
            e = end,
            final = s + (((e - s) / steps) * count);
        return Math.floor(final);
    }

    return (
        <>
            <ReactApexChart options={options} series={[valueFormatter()]} type="radialBar"
                          height={props.pWidth}
            />
            <div className="device-name-label" style={{fontSize:props.pWidth/14}}>{props.status}</div>
        </>

    );


};
export default Gauge;
