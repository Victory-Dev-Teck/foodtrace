
export const getUtcTimeStamp = (dateStr) => {
    let createTime = new Date(dateStr);
    let diff = createTime.getTimezoneOffset() * 60 * 1000;
    let timestamp = createTime.getTime() - diff;
    return timestamp;
};